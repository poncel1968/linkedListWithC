#ifndef LISTADOS
#define LSITADOS

int listados_clientes_ordenarPorApellido(cliente* array, int limite);
int listados_ventasPorIdCliente(cliente* arrayClientes,int limiteCliente, ventas* arrayVentas, int limiteVentas);
int listados_clientesPorCantidadAfiches(cliente* arrayClientes,int limiteCliente, ventas* arrayVentas, int limiteVentas);
int listados_clientesPorCantidadAfiches(cliente* arrayClientes,int limiteCliente, ventas* arrayVentas, int limiteVentas);
#endif
