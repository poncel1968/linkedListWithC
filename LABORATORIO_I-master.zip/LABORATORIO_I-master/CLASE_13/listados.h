int listado_ordenado (Pantalla * array, int limite);

int listado_pantallas (Pantalla * array, int limite);

int listado_pantallasMenor (Pantalla * array, int limite,int valor);

int promedio_preciopantalla (Pantalla * array, int limite,float* promedio);

int listado_pantallasMenorPromedio (Pantalla* array, int limite,float* promedio);

