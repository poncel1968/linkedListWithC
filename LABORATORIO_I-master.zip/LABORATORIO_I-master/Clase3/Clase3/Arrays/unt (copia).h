int retornarTotal(int array[],int cant );
void cargarListado(int listado[],int cant);

