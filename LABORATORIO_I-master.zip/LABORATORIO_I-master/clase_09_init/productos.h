typedef struct
{
    char nombre[50];
    char descripcion[200];
    float precio;
    int isEmpty;

} Producto;
int producto_altaProducto(Producto arrayProducto[],int len, int indice);


