

int utn_getString(char* arrayString, int limite,char* msg,char* msgError);
int utn_getInt(int* valor,int limitedigit);
int validarIntInStr(char* stringInt, int limitedigit );
int validarStrTelefono(char* stringInt, int limitedigit );
int validarNombreInStr(char* stringInt);
int utn_getNombre(char* nombre,int limite,char* msg);
int validarFloatInStr(char* stringFloat, int limitedigit );
int utn_getFloat(float* valor,int limitedigit);





